//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    
    lazy var tappable: UIButton = {
        let buttonPoint = CGPoint(x: 125, y: 275)
        let buttonSize = CGRect(origin: buttonPoint, size: CGSize(width: 120, height: 50))
        let tappable = UIButton(frame: buttonSize)
        tappable.backgroundColor = .orange
        tappable.layer.borderColor = UIColor.white.cgColor
        tappable.layer.borderWidth = 2
        tappable.layer.cornerRadius = 8
        tappable.setTitleColor(.white, for: .normal)
        tappable.setImage(UIImage(named: "white-arrow"), for: .normal)
        tappable.imageView?.contentMode = .scaleAspectFit
        tappable.imageEdgeInsets = UIEdgeInsets(top: 14, left: -16, bottom: 14, right: 0)
        tappable.setTitle("Back to lobby", for: .normal)
        tappable.titleLabel?.font = importedFont()
        tappable.titleLabel?.contentMode = .scaleToFill
        tappable.titleLabel?.minimumScaleFactor = 0.5
        tappable.titleLabel?.lineBreakMode = .byWordWrapping
        tappable.titleLabel?.textAlignment = .center
        tappable.titleLabel?.clipsToBounds = true
        tappable.titleEdgeInsets = UIEdgeInsets(top: 0, left: -12, bottom: 0, right: 4)
        return tappable
    }()
    
    private func importedFont() -> UIFont {
        let cfURL = Bundle.main.url(forResource: "Montserrat-Bold", withExtension: "ttf") as! CFURL
        CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
        return UIFont(name: "Montserrat-Bold", size: 16) ?? UIFont.systemFont(ofSize: 14)
    }
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .black
        view.addSubview(tappable)
        self.view = view
    }
}
// Present the view controller in the Live View window
 PlaygroundPage.current.liveView = MyViewController()
